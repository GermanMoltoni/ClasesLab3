var Avenger = (function () {
    function Avenger() {
    }
    return Avenger;
}());
var antman = new Avenger();
console.log(antman);
