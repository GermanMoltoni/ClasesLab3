
class Avenger {
    nombre:string;
    equipo:string;
    nombreReal:string;
    puedePelear:boolean;
    peleasGanadas:number;
}

let antman:Avenger= new Avenger();

console.log(antman);

