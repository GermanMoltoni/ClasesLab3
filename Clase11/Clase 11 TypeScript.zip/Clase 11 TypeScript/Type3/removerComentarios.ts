/*!
lñksñlkfñlkglñklgñkdlñgkdgñlkgdkgl
ksñlgksgñldskgñlskgfñlsgfkñslgfksgñlksf
kñlsksñlgksñlgksgñlgsklgñsklgsñlgk
*/

//Heroe es el personaje principal
let heroe1:string = "Ricardo Tapia (Robin)";

//esta variable contiene la edad...
let edad1:number = 30;

//=======================================
//Esta es la función que imprime al heroe
//=======================================

function imprimir1(herote:string, edad:number){
    heroe = heroe.toLowerCase();
    edad = edad + 10;

    return heroe + " " + edad;
}

let mensaje:string = imprimir1(heroe1, edad1);

console.log(mensaje);