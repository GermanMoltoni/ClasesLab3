console.log(saludo + " a todos");
