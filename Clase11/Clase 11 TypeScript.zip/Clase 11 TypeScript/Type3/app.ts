let heroe:string = "Ricardo Tapia (Robin)";
let edad:number = 30;

function imprimir(herote:string, edad:number){
    heroe = heroe.toLowerCase();
    edad = edad + 10;

    return heroe + " " + edad;
}

console.log(imprimir(heroe, edad));

