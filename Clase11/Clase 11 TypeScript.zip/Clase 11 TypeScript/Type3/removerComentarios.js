/*!
lñksñlkfñlkglñklgñkdlñgkdgñlkgdkgl
ksñlgksgñldskgñlskgfñlsgfkñslgfksgñlksf
kñlsksñlgksñlgksgñlgsklgñsklgsñlgk
*/
//Heroe es el personaje principal
var heroe1 = "Ricardo Tapia (Robin)";
//esta variable contiene la edad...
var edad1 = 30;
//=======================================
//Esta es la función que imprime al heroe
//=======================================
function imprimir1(herote, edad) {
    heroe = heroe.toLowerCase();
    edad = edad + 10;
    return heroe + " " + edad;
}
var mensaje = imprimir1(heroe1, edad1);
console.log(mensaje);
