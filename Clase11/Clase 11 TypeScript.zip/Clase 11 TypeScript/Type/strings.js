var batman = "Batman";
var superman = "Superman";
var linternaVerde = "Linterna Verde";
var frase = "Los Heroes son: " + batman + ", " + superman + ", " + linternaVerde;
var concat = "Los Heroes son: " + batman + ", " + superman + ", " + linternaVerde;
console.log(frase);
console.log(concat);
