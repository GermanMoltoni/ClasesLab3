let heroe:string = "Flash";

function imprime_heroe():string{
    return heroe;
}

let activar_batisenal = function():string{
    return "Batiseñal activada";
}

console.log( imprime_heroe());

console.log(activar_batisenal());