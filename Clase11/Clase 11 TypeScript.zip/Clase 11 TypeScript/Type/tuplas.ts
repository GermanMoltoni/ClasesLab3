//let heroe = ["Dr. Strange", 100];

let heroe: [string, number, boolean] = ["Dr. Strange", 100];

heroe[0] = "Ironman";
heroe[1] = 123;

heroe.push(true);

heroe[2] = true;

