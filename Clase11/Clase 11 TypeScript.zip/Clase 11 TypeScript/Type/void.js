function llamarABatman() {
    console.log("Mostrar la Batiseñal");
}
