let vengador;
let existe;
let derrotas;


vengador = "Dr. Strange";

console.log(vengador.charAt(0));

vengador = 123.2222;

console.log(vengador.toFixed(2));

vengador = true;

console.log(vengador);


