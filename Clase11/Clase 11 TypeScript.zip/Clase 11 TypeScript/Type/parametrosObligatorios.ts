function nombreCompleto( nombre:string, apellido:string ):string{
    return nombre + ' ' + apellido;
}

let nombre = nombreCompleto();
//me obliga a colocar los parámetros

console.log(nombre);
