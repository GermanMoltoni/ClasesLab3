let esSuperman:boolean = true;
let esBatman:boolean;
let esAquaman = true;

//esSuperman =  convertirClark();


if(esSuperman){
    console.log("Estamos Salvados!!!");
}
else{
    console.log("Ooooops!");
}

esSuperman =  convertirClark();


function convertirClark(){
    return false;
}