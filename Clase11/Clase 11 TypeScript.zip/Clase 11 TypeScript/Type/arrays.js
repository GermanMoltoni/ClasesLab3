var vector = [1, 3, 4, 2, 5];
//vector[3] = "Hola";
vector.push(4);
console.log(vector);
console.log(vector.pop());
