var heroe = "Flash";
function imprime_heroe() {
    return heroe;
}
var activar_batisenal = function () {
    return "Batiseñal activada";
};
console.log(imprime_heroe());
console.log(activar_batisenal());
