"use strict";
//no influye el orden
var flash = {
    nombre: "Barry Allen",
    edad: 24,
    //edad:"24",
    poderes: ["Corre muy rápido", "Viaja en el tiempo"]
    //getNombre(){   }
};
// flash.getNombre();
