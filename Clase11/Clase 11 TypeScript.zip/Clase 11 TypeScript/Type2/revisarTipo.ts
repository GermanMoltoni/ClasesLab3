let cosa:any = 123;

if(typeof(cosa) === "number"){ //typeof retorna un string
    

    console.log("Cosa en un " + cosa);

}