"use strict";
var flash = {
    nombre: "Barry Allen",
    edad: 24,
    poderes: ["Corre muy rápido", "Viaja en el tiempo"],
    getNombre: function () {
        return this.nombre;
    }
};
var superman = {
    nombre: "Clark Kent",
    edad: 500,
    poderes: ["Vuela", "Superfuerza"],
    getNombre: function () {
        return this.nombre;
    }
};
