
console.log(
    Validaciones.validarTexto("Barry Allen")
);

